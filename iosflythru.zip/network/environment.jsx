export const BASE_URL="http://localhost:2001";
// export const LOCAL_URL="http://192.168.1.18:3000";
export const LOCAL_URL="https://admin.flythru.net";

const API_KEY = 'a601a685ef6add9deaa1c103d7ac3f38';
const AVIATION_URL = 'https://api.aviationstack.com/v1';