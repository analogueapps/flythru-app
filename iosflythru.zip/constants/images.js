import HeroHeader from "../assets/images/HeroHeader.png";
import mainLogo from "../assets/images/mainLogo.png";
import whiteLogo from "../assets/images/whiteLogo.png";
import airlinesLogo from "../assets/images/airlinesLogo.png";
import HeaderImg from "../assets/images/HeaderImg.png";
import HeaderImg2 from "../assets/images/HeaderImg2.png";

export default {
  HeroHeader,
  mainLogo,
  whiteLogo,
  airlinesLogo,
  HeaderImg,
  HeaderImg2,
};
